#!/usr/bin/env python
# coding: utf-8

# In[1]:


#title case
def myName(fname,lname):
    print(fname.title())
    print(lname.title())
    


# In[9]:


myName('masood','iqbal')


# In[10]:


#returning a string
def myNameInString():
    return "masood iqbal"


# In[11]:


print(myNameInString())


# In[12]:


def myNamewithReturn(fname,lname):
    return f"{fname.title()} {lname.title()}"


# In[13]:


titleName = myNamewithReturn('masood','iqbal')
print(titleName)


# In[14]:


titleName = myNamewithReturn(input("Enter your first name:"),input("Enter your last name:"))
print(titleName)


# In[15]:


#multiple values return
def myNameWithReturns(fname,lname):
    if fname == "" or lname == "":
        return
    return f"{fname.title()} {lname.title()}"
    


# In[17]:


titleName = myNameWithReturns(input("Enter your first name:"),input("Enter your last name:"))
print(titleName)


# In[18]:


#leap year
def isLeap(year):
    if year % 4 == 0:
        return True
    else:
        return False


# In[19]:


def daysInMonth(year,month):
    month_days = [31,28,31,30,31,30,31,31,30,31,30,31]
    if isLeap(year) and month == 2:
        return 29
    return month_days[month-1]


# In[21]:


year = int(input("Enter a year: "))
month = int(input("Enter a month: "))
days = daysInMonth(year,month)
print(days)


# In[22]:


#Docstrings: a docstring is a string literal specified in source code 
# that is used, like a comment, 
# to document a specific segment of code (shift+tab)
def foo():
    """Testing a docstring"""
    print("Anything")


# In[23]:


foo()


# In[24]:


#calculator
def add(num1,num2):
    return num1+num2

def sub(num1,num2):
    return num1-num2

def mul(num1,num2):
    return num1 * num2

def div(num1,num2):
    return num1 / num2
    


# In[25]:


operations = {
    
    "+": add,
    "-": sub,
    "*": mul,
    "/": div
}


# In[26]:


num1 = int(input("What is the first number?:")) # 3

for symbol in operations:
    print(symbol)

operator = input("Pick an operation from the above:") #*

num2 = int(input("What is the second number?:"))  # 4

#function calling

function = operations[operator]
result = function(num1,num2) # 7


# In[27]:


print(num1,operator,num2,"=",result)


# In[104]:


#Guess Game
# import random
from random import randint
EASY_LEVEL_TURNS = 10
HARD_LEVEL_TURNS = 5

# print("Welcome to the Guessing Game!")
# print("I'm thinking of a number between  1 and 100.")

# #choosing a random number
# answer = randint(1,100)


# In[105]:


# #let the user guess a number
# guess = int(input("Make a guess:"))


# In[106]:


#Function to check user's guess against actual answer
def checkAnswer(guess,answer,turns):
    if guess > answer:
        print("Too high.")
        return turns - 1
    elif guess < answer:
        print("Too low.")
        return turns - 1
    else:
        print("You got it! The answer was:",answer)


# In[107]:


#setting the difficultyu
def setDifficulty():
    level = input("Choose a difficulty. Type 'easy' or 'hard': ")
    if level == "easy":
        
        return EASY_LEVEL_TURNS
    else:
        return HARD_LEVEL_TURNS


# In[108]:


# turns = setDifficulty()
# print("You have" ,turns, "attempts remaining to guess the number.")
# checkAnswer(guess,answer)


# In[109]:


#put all key things into a function
def game():
    print(logo)
    print("Welcome to the Guessing Game!")
    print("I'm thinking of a number between  1 and 100.")

    #choosing a random number
    answer = randint(1,100)
    
    turns = setDifficulty()
    print("You have" ,turns, "attempts remaining to guess the number.")
    
    guess = 0
    while guess != answer:
        print("You have" ,turns, "attempts remaining to guess the number.")
        #let the user guess a number
        guess = int(input("Make a guess:"))
        turns = checkAnswer(guess,answer,turns)
        
        #stopping the func
        if turns == 0:
            print("You have run out of guesses, you lose.")
            return
        elif guess != answer:
            print("Guess again.")
        


# In[110]:


from art import logo
game()


# 

# In[ ]:


list = [23,44,55,66]
list.sort()

