#!/usr/bin/env python
# coding: utf-8

# In[1]:


#scope vs life time
#namespace : anything you give a name is called namespace
#namespace:A namespace is a declarative region that provides a scope to the identifiers (the names of types, functions, variables, etc) inside it. Namespaces are used to organize code into logical groups and to prevent name collisions that can occur especially when your code base includes multiple libraries
enemies = 1
def increaseEnimies():
    enemies = 2
    print("enemies:",enemies)
    
increaseEnimies()
print("enemies:",enemies)


# In[3]:


#Local Scope : exists with in funtion or certain bounds

def foo():
    num = 3
    print(num) #fine
    
foo()
print(num) #Error


# In[6]:


#Global scope
num = 2
def foo():
    num = 3
    print(num) #fine
    
foo()
print(num) #fine


# In[8]:


#There is no BLOCK SCOPE IN PYTHON LIKE C,C++,JAVA etc (Not in loop,conditons any block scope in python but in functions)
level = 3
def createEnemy():
    enemies = ["Osama","Zaman","Moosa"]
    if level < 5:
        newEnemy = enemies[0]
# print(newEnemy)#error


# In[10]:


level = 3
enemies = ["Osama","Zaman","Moosa"]
if level < 5:
    newEnemy = enemies[0]
    
print(newEnemy)


# In[11]:


#Modifying global Scope
enemies = 1
def increaseEnimies():
    enemies = 2 #its a completely new variable
    print("enemies:",enemies)
    
increaseEnimies()
print("enemies:",enemies)


# In[15]:


#Modifying global Scope (but avoid modifying)
enemies = 1
def increaseEnimies():
    global enemies 
    enemies = 2 #same variable
    print("enemies:",enemies)
    
increaseEnimies()
print("enemies:",enemies)


# In[17]:


#Global is used to create global contants
PI = 3.14159
URL = "https://www.google.com"


# In[ ]:




